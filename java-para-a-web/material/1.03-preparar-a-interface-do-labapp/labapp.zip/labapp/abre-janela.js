// Abre a janela que o botão aponta (data-abre="id da janela").
// Se o botão trouxer data-id, data-titulo e data-prioridade, copia pros campos
// da janela: é assim que a janela de editar e a de excluir sabem de qual tarefa
// se trata. Fechar e enviar não precisam de JavaScript: são do formulário.
const botoesQueAbremJanela = document.querySelectorAll('[data-abre]');

for (const botao of botoesQueAbremJanela) {
  botao.addEventListener('click', () => abrirJanela(botao));
}

function abrirJanela(botao) {
  const janela = document.getElementById(botao.dataset.abre);
  if (!janela) return;

  janela.querySelector('form').reset();
  preencherComATarefa(janela, botao.dataset);
  janela.showModal();
}

function preencherComATarefa(janela, dadosDoBotao) {
  preencherCampo(janela, 'id', dadosDoBotao.id);
  preencherCampo(janela, 'titulo', dadosDoBotao.titulo);
  preencherCampo(janela, 'prioridade', dadosDoBotao.prioridade);

  const nomeDaTarefa = janela.querySelector('.nome-da-tarefa');
  if (nomeDaTarefa) nomeDaTarefa.textContent = dadosDoBotao.titulo ?? '';
}

function preencherCampo(janela, nome, valor) {
  const campo = janela.querySelector(`[name="${nome}"]`);
  if (campo && valor !== undefined) campo.value = valor;
}
